@echo off
if "%~1" == "" goto regwinbox

FOR /f "tokens=2 delims==" %%f IN ('wmic os get osarchitecture /value ^| find "="') DO SET "OS_ARCH=%%f"

if "%OS_ARCH%"=="64-bit" start c:\winbox64.exe %2 %3 %4 
if "%OS_ARCH%"=="32-bit" start c:\winbox.exe %2 %3 %4
PAUSE
exit



:regwinbox

set key=winbox
reg add HKCR\%key% /ve /f /d "Winbox" 
reg add HKCR\%key% /v /f "URL Protocol" /d ""
reg add HKCR\%key%\shell /f
reg add HKCR\%key%\shell\open /f 
reg add HKCR\%key%\shell\open\command /ve /f /d ""c:\winbox.bat" %%1"
